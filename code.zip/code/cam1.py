import sys
import cv
from PyQt4 import QtGui, QtCore, uic,Qt
import cv2
from ftplib import FTP
import numpy
import os
import psycopg2
import datetime

PatientId = -1
pid = ''
class CameraDevice(QtCore.QObject):
 
    _DEFAULT_FPS = 15
 
    newFrame = QtCore.pyqtSignal(cv.iplimage,numpy.ndarray)
 
    def __init__(self, cameraId=-1, mirrored=False, parent=None):
        super(CameraDevice, self).__init__(parent)

 
        self.mirrored = mirrored
 
        self._cameraDevice = cv.CaptureFromCAM(cameraId)
        cv.SetCaptureProperty(self._cameraDevice,cv.CV_CAP_PROP_FRAME_WIDTH, 1280)
        cv.SetCaptureProperty(self._cameraDevice,cv.CV_CAP_PROP_FRAME_HEIGHT, 720)
        self._timer = QtCore.QTimer(self)
        self._timer.timeout.connect(self._queryFrame)
        self._timer.setInterval(1000/self.fps)
 
        self.paused = False
        #print "-->",self._timer.isActive()
        #print "cameraDevice"
 
    @QtCore.pyqtSlot()
    def _queryFrame(self):
    	#print "_queryFrame"
        frame = cv.QueryFrame(self._cameraDevice)
        #print "tyoe",type(frame)
        if self.mirrored:
            mirroredFrame = cv.CreateImage(cv.GetSize(frame), frame.depth, frame.nChannels)
            cv.Flip(frame, mirroredFrame, 1)
            frame = mirroredFrame
            frame_mat = numpy.asarray(frame[:,:])

        #print "frame_mat",type(frame_mat)
        self.newFrame.emit(frame,frame_mat)
 
    @property
    def paused(self):
        return not self._timer.isActive()
 
    @paused.setter
    def paused(self, p):
        if p:
            self._timer.stop()
        else:
            self._timer.start()	
 
    @property
    def frameSize(self):
        w = cv.GetCaptureProperty(self._cameraDevice, \
            cv.CV_CAP_PROP_FRAME_WIDTH)
        h = cv.GetCaptureProperty(self._cameraDevice, \
            cv.CV_CAP_PROP_FRAME_HEIGHT)
        return int(w), int(h)
 
    @property
    def fps(self):
        fps = int(cv.GetCaptureProperty(self._cameraDevice, cv.CV_CAP_PROP_FPS))
        if not fps > 0:
            fps = self._DEFAULT_FPS
        return fps

class CameraWidget(QtGui.QWidget):
 
    newFrame = QtCore.pyqtSignal(cv.iplimage,numpy.ndarray)
 
    def __init__(self, cameraDevice, parent=None):
        super(CameraWidget, self).__init__(parent)

        palette = QtGui.QPalette()
        color = QtGui.QColor(188,210,238)
        palette.setColor(QtGui.QPalette.Background,color)
        self.setPalette(palette)

        self.setWindowTitle('Preview')
        self.geometry = QtGui.QApplication.desktop().availableGeometry()
        print "ggg  ",self.geometry.center()
        self.setGeometry(QtGui.QApplication.desktop().availableGeometry())

        self.progressBar = QtGui.QProgressBar(self)
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(0)
        self.progressBar.hide()
        rec_icon = QtGui.QIcon('rec.png')
        stop_icon = QtGui.QIcon('stop.png')
        
        self.ss_list = []
        self.ss_name = ''
        self.vid_name = ''
        self.cnt = 1
        self.cnt_vid = 1
        btn_record = QtGui.QPushButton(rec_icon,'Record',self)
        btn_stop = QtGui.QPushButton(stop_icon,'Stop',self)

        btn_record.clicked.connect(self.record)
        btn_stop.clicked.connect(self.stop)

        hbox = QtGui.QHBoxLayout()
        hbox.addStretch(1)
        hbox.addWidget(btn_record)
        hbox.addWidget(btn_stop)
        hbox.addStretch(1)

        hbox1 = QtGui.QHBoxLayout()
        hbox1.addStretch(1)
        hbox1.addWidget(self.progressBar)
        hbox1.addStretch(1)        

        vbox = QtGui.QVBoxLayout()
        vbox.addStretch(12)
        vbox.addLayout(hbox)
        vbox.addLayout(hbox1)
        vbox.addStretch(1)
        self.setLayout(vbox)
        self._frame = None
        self._cameraDevice = cameraDevice
        self._cameraDevice.newFrame.connect(self._onNewFrame)
        self.resize(1280,720)
        w, h = self._cameraDevice.frameSize
        #self.setMinimumSize(w, h)
        self.record_flag = 0
        #self.setMaximumSize(1366, 768)
        #self.fourcc = cv.CV_FOURCC('L','M','P','4')
        self.fourcc = cv.CV_FOURCC('D','I','V','X')
        
        
    def updateDateTime(self):
        print "updateDateTime"
        self.d1 = datetime.datetime.now()
        self.d = self.d1.date()
        self.h = self.d1.time().hour
        self.m = self.d1.time().minute
        self.s = self.d1.time().second
    def closeEvent(self,e):
    	print "event:",e
        #self.out.release()
        newpid = os.fork()
        if newpid==0:
            ftp = FTP('192.168.43.103')
            ftp.login(user='user',passwd='cit1')
            self.size = 0
            for fname in self.ss_list:
                self.size += os.path.getsize(fname)
                print self.size
            for fname in self.ss_list:
                print "fname:::::",fname
                #ftp.mkd('/Videos/'+str(pid))
                ftp.storbinary('STOR /tomcat/Videos/'+pid+'/'+str(fname), open(str(fname), 'rb'))
                #ftp.storbinary('STOR /Videos/'+pid+'/'+str(fname), open(str(fname), 'rb'))
        #self.vf = VideoFunction()
        #self.writer.release
    	
    	#print "complete"
    	#del self.writer
    def record(self):
    	self.record_flag = 1
        self.updateDateTime()
        self.vid_name = str(pid)+'_'+str(self.d)+'_'+str(self.h)+'_'+str(self.m)+'_'+str(self.s)+'_'+str(self.cnt_vid)+'_vid_.mkv'
        print "self.vid_name this matters---",self.vid_name
        self.out = cv2.VideoWriter(self.vid_name,self.fourcc, _DEFAULT_FPS  , (1280,720))
        self.ss_list.append(self.vid_name)
        self.progressBar.show()
    def stop(self):
        self.out.release()
        self.record_flag = 0
        self.progressBar.hide()
        self.cnt_vid += 1
    @QtCore.pyqtSlot(cv.iplimage,numpy.ndarray)
    def _onNewFrame(self, frame,frame_mat):
        if self.record_flag==1:
            print "recording..."
            self.out.write(frame_mat)
        self._frame = cv.CloneImage(frame)
        self._frame_mat = frame_mat
        self.newFrame.emit(self._frame,frame_mat)
        self.update()
 
    def keyPressEvent(self,event):
        print "event keyPressEvent",event
        if type(event) == QtGui.QKeyEvent and event.key() == QtCore.Qt.Key_A :
            self.updateDateTime()
            self.ss_name = str(pid)+'_'+str(self.d)+'_'+str(self.h)+'_'+str(self.m)+'_'+str(self.s)+str(self.cnt)+'_ss_.jpeg'
            cv2.imwrite(self.ss_name,self._frame_mat)
            self.ss_list.append(self.ss_name)
            print self.ss_list
            self.cnt += 1
            
    def changeEvent(self, e):
    	#print "changeEvent"
        if e.type() == QtCore.QEvent.EnabledChange:
            if self.isEnabled():
                self._cameraDevice.newFrame.connect(self._onNewFrame)
            else:
                self._cameraDevice.newFrame.disconnect(self._onNewFrame)
 
    def paintEvent(self, e):
        if self._frame is None:
            return
        painter = QtGui.QPainter(self)
        '''size = QtCore.QSize(1280,720)
        rect = QtCore.QRect(self.geometry.topLeft(),size)
        rect.moveCenter(self.geometry.center())
        painter.drawImage(rect, OpenCVQImage(self._frame))'''
        painter.drawImage(QtCore.QPoint(0,0),OpenCVQImage(self._frame))
class OpenCVQImage(QtGui.QImage):
 
    def __init__(self, opencvBgrImg):
        depth, nChannels = opencvBgrImg.depth, opencvBgrImg.nChannels
        if depth != cv.IPL_DEPTH_8U or nChannels != 3:
        	raise ValueError("the input image must be 8-bit, 3-channel")
        w, h = cv.GetSize(opencvBgrImg)
        opencvRgbImg = cv.CreateImage((w, h), depth, nChannels)
        # it's assumed the image is in BGR format
        cv.CvtColor(opencvBgrImg, opencvRgbImg, cv.CV_BGR2RGB)
        self._imgData = opencvRgbImg.tostring()
        super(OpenCVQImage, self).__init__(self._imgData, w, h, QtGui.QImage.Format_RGB888)

class VideoFunction(QtGui.QWidget):
    def __init__(self):
        super(VideoFunction,self).__init__()
        self.initUI()
    def initUI(self):
        palette = QtGui.QPalette()
        color = QtGui.QColor(188,210,238)
        palette.setColor(QtGui.QPalette.Background,color)
        self.setPalette(palette)

        
        BtnIcon = QtGui.QIcon("cam2.png")
        BtnPreview = QtGui.QPushButton(BtnIcon,'Preview',self)
        
        hbox = QtGui.QHBoxLayout()
        hbox.addStretch(1)
        hbox.addWidget(BtnPreview)
        hbox.addStretch(1)

        vbox = QtGui.QVBoxLayout()
        vbox.addStretch(1)
        vbox.addLayout(hbox)
        vbox.addStretch(1)


        self.setLayout(vbox)
        self.setWindowTitle('Video')
        geometry = QtGui.QApplication.desktop().availableGeometry()
        self.setGeometry(QtGui.QApplication.desktop().availableGeometry())
        self.show()

        self.connect(BtnPreview, QtCore.SIGNAL("clicked()"), self.preview)

    def preview(self):
        self.cameraDevice = CameraDevice(mirrored=True)
        self.cameraWidget2 = CameraWidget(self.cameraDevice)
        self.close()
        self.cameraWidget2.show()

class PatientSel(QtGui.QWidget):
    def __init__(self):
        super(PatientSel,self).__init__()
        self.initUI()
    def initUI(self):
        #print geometry
        #print geometry.top()
        

        
        
        palette = QtGui.QPalette()
        color = QtGui.QColor(188,210,238)
        palette.setColor(QtGui.QPalette.Background,color)
        self.setPalette(palette)
        #myPixmap = QtGui.QPixmap('test.jpg')
        #myScaledPixmap = myPixmap.scaled(geometry.bottom()-geometry.top(),geometry.right()-geometry.left(), 2)
        #palette.setBrush(QtGui.QPalette.Background, QtGui.QBrush(myPixmap))
        
        #All the Widgets
        self.BtnSearch = QtGui.QPushButton('Search',self)
        self.patId = QtGui.QLineEdit('',self)
        self.lPatId = QtGui.QLabel('Enter Patient ID')
        #self.RPatId = QtGui.QRadioButton('Search By ID',self)
        #self.patName = QtGui.QLineEdit('',self)
        #self.RPatName = QtGui.QRadioButton('Search By Name',self)
        #Layout for lineEdit and radio buttons
        hbox = QtGui.QHBoxLayout()
        hbox.addStretch(1)
        hbox.addWidget(self.lPatId)
        #hbox.addWidget(self.RPatId)
        hbox.addWidget(self.patId)
        #hbox.addWidget(self.RPatName)
        #hbox.addWidget(self.patName)
        hbox.addStretch(1)
        #layour for button
        hbox1 = QtGui.QHBoxLayout()
        hbox1.addStretch(1)
        hbox1.addWidget(self.BtnSearch)
        hbox1.addStretch(1)
        
        #layout for both the layouts
        vbox = QtGui.QVBoxLayout()
        vbox.addStretch(1)
        vbox.addLayout(hbox)
        vbox.addLayout(hbox1)
        vbox.addStretch(1)

        self.setLayout(vbox)

        self.setWindowTitle('Patient Selection')
        geometry = QtGui.QApplication.desktop().availableGeometry()
        self.setGeometry(QtGui.QApplication.desktop().availableGeometry())

        self.show()
        self.connect(self.BtnSearch, QtCore.SIGNAL("clicked()"), self.getPatientId)
    def getPatientId(self):
        
        ID = "-1"
        #name = "-1"
        ID = str(self.patId.text()).strip()
        print "ID",ID
        global pid
        pid = ID
        #name = str(self.patName.text()).strip()
        print ID
        #print name
        conn = psycopg2.connect("dbname='postgres' user='postgres' host='192.168.43.103' password='new'")
        #conn = psycopg2.connect("dbname='201201119' user='201201119' host='10.100.71.21' password='201201119'")
        if conn:
            print "1"
        else:
            print "2"
        cur = conn.cursor()
        cur.execute("SET search_path to ehr")

        sql1 = "SELECT pid from patient_general where pid = (%s)"
        data1 = (ID,)

        #data2 = (name,)
        #sql2 = "SELECT pid from patient_general where name = (%s)"

        cur.execute(sql1,data1)
        id1 = cur.fetchall()
        print "ID1"
        print id1
        print id1[0][0]

        #print "B"
        #cur.execute(sql2,data2)
        #id2 = cur.fetchall()
        #print id2
        #print id2[0][0]

        print self.patId.text()
        #print self.patName.text()
        
        if id1 != -1:
            PatientId = id1
            self.close()
            self.vf = VideoFunction()
        else:
            self.getPatientId()
        '''elif id2 != -1:
            PatientId = id2
            self.close()
            self.vf = VideoFunction()'''
        #self.close()
        #self.vf = VideoFunction()
        print "A"
def _main():
	app = QtGui.QApplication(sys.argv)
	ps = PatientSel()
	#cameraDevice = CameraDevice(mirrored=True)
	#cameraWidget2 = CameraWidget(cameraDevice)
	#cameraWidget2.show()
	sys.exit(app.exec_())
if __name__=='__main__':
	_main()
